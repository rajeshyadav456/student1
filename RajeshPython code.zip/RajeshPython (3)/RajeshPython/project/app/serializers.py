from rest_framework import serializers
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from .models import *
from django.contrib.auth import get_user_model
User = get_user_model()
from django.core.exceptions import ValidationError
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

class LoginSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls,user):
        token=super().get_token(user)
        token['phone']=user.phone
        return token
    
class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser  
        fields = ('id', 'phone', 'password')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User(
            phone=validated_data['phone']
        )
        user.set_password(validated_data['password'])
        user.save()
        return user
    
class RegisterSerializer(serializers.Serializer):
    first_name=serializers.CharField(max_length=100)
    last_name=serializers.CharField(max_length=100)
    phone=serializers.CharField(max_length=16)
    email=serializers.EmailField()
    class_name_id= serializers.PrimaryKeyRelatedField(queryset=Class.objects.all())  
    class_name_id_name = serializers.SerializerMethodField() 
    is_active=serializers.BooleanField(default=False,read_only=True)
    password=serializers.CharField(max_length=100,write_only=True)

    def get_class_name_id_name(self, obj):
        return obj.class_name_id.name if obj.class_name_id else None
    
    def validate(self,attrs):
        phone=attrs.get('phone')
        user=CustomUser.objects.filter(phone=phone).exists()
        if user:
            raise ValidationError('User already Exists.')
        return super().validate(attrs)
    def create(self,validated_data):
        user=CustomUser.objects.create_user(**validated_data)
        return user
    
    
class UserLoginSerializer(serializers.Serializer):
    phone = serializers.CharField()
    password = serializers.CharField(write_only=True)

    def validate(self, data):
        phone = data.get('phone')
        password = data.get('password')

        user = authenticate(phone=phone, password=password)

        if user and user.is_active:
            data['user'] = user
        else:
            raise serializers.ValidationError("Inactive User.")

        return data

    def create(self, validated_data):
        user = validated_data['user']
        token, created = Token.objects.get_or_create(user=user)
        return user, token.key
    
class UserProfileUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ('id', 'first_name','last_name', 'phone','email','dob') 