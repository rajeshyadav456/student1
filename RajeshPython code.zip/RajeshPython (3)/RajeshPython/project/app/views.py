from django.shortcuts import render
from .models import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from rest_framework import status
from rest_framework.authtoken.models import Token
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework import generics
from .serializers import *
from rest_framework.permissions import AllowAny
from rest_framework.authentication import TokenAuthentication
from .forms import *
# Create your views here.
class HelloView(APIView):
    permission_classes = (IsAuthenticated,)

    def get(self, request):
        content = {'message': 'Hello, World!'}
        return Response(content)



def add_class(request):
    if request.method == 'POST':
        form = ClassNameForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')  
    else:
        form = ClassNameForm()
    return render(request, 'add_class.html', {'form': form})

class RegisterAPIView(generics.CreateAPIView):
    serializer_class=RegisterSerializer

    def create (self,request,*args,**kwargs):
        serializer=self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        refresh=LoginSerializer.get_token(serializer.instance)
        data={**serializer.data}
        data['id']=serializer.instance.id
        data['refresh']=str(refresh)
        data['access']=str(refresh.access_token)

        headers=self.get_success_headers(serializer.data)
        return Response(data,status=status.HTTP_201_CREATED,headers=headers)


class UserLoginView(APIView):
    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        if serializer.is_valid():
            user, token_key = serializer.save()
            return Response({'user_id': user.id, 'token': token_key})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserProfileUpdateView(APIView):
    authentication_classes = [TokenAuthentication]

    def get_object(self, user_id):
        try:
            return CustomUser.objects.get(id=user_id)
        except CustomUser.DoesNotExist:
            return None

    def put(self, request, user_id, format=None):
        user = self.get_object(user_id)
        if not user:
            return Response({"error": "User not found."}, status=status.HTTP_404_NOT_FOUND)

        serializer = UserProfileUpdateSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class RegisterView(APIView):
    def get(self, request):
        classes = Class.objects.all()
        return render(request, 'register_student.html', {'classes': classes})

    def post(self, request):
        serializer = RegisterSerializer(data=request.POST)
        if serializer.is_valid():
            user = serializer.save()
            return redirect('/')  
        return render(request, 'register_student.html', {'serializer': serializer})
    



class UserLoginViewdata(APIView):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        serializer = UserLoginSerializer(data=request.POST)
        if serializer.is_valid():
            user, token_key = serializer.save()
            login(request, user)  # Log in the user
            return redirect('register')  # Redirect to the register page
        return render(request, 'login.html', {'serializer': serializer})