from django.contrib import admin
from django.urls import path,include
from rest_framework_simplejwt import views as jwt_views
from rest_framework.authtoken.views import obtain_auth_token
from .views import *
urlpatterns = [
      # path('api/login/', jwt_views.TokenObtainPairView.as_view(), name='token_obtain_pair'),
      path('api/token/refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
      path('add_class/', add_class, name='add_class'),
      path('api/register/', RegisterAPIView.as_view(), name='register'),
      path('api/login/', UserLoginView.as_view(), name='login'),
      path('api/update/<int:user_id>/',UserProfileUpdateView.as_view(),name='upadate'),
      path('register/', RegisterView.as_view(), name='register'),
      path('login/', UserLoginViewdata.as_view(), name='login'),







]
