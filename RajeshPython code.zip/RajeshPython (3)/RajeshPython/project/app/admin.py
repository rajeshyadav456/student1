from django.contrib import admin
from .models import *
# Register your models here.
class StudentAdmin(admin.ModelAdmin):
    list_display = ('phone', 'is_active', 'class_name_id')

    def status_display(self, obj):
        return obj.get_status_display()

    status_display.short_description = 'Status'

    actions = ['activate_students', 'deactivate_students']

    def activate_students(self, request, queryset):
        queryset.update(status='active')

    def deactivate_students(self, request, queryset):
        queryset.update(status='inactive')

    activate_students.short_description = 'Activate selected students'
    deactivate_students.short_description = 'Deactivate selected students'

admin.site.register(CustomUser,StudentAdmin)
admin.site.register(Class)

