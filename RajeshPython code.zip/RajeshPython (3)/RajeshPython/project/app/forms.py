from django import forms
from .models import *
from django.contrib.auth.models import User

class ClassNameForm(forms.ModelForm):
    class Meta:
        model = Class
        fields = ['name']



# class StudentForm(forms.ModelForm):
#     class Meta:
#         model = Student
#         fields = ['first_name','last_name','phone', 'dob', 'status', 'image', 'class_id']

# class UserForm(forms.ModelForm):
#     class Meta:
#         model = User
#         fields = ['username', 'email', 'password']
#         widgets = {
#             'password': forms.PasswordInput(),
#         }
# class StudentForm(forms.ModelForm):
#     class Meta:
#         model = Student
#         fields = ['first_name','last_name','phone', 'dob', 'image', 'class_id']