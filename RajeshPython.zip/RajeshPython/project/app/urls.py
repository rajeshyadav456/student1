from django.contrib import admin
from django.urls import path,include
from .views import *
urlpatterns = [
    path('signup/', signup_view, name='signup'),
    path('login/',login_view, name='login'),
    path('home/',home,name='home'),
    path('', post_list, name='post_list'),
    path('post/<int:post_id>/', post_detail, name='post_detail'),
    path('like_comment/<int:comment_id>/', like_comment, name='like_comment'),
    path('<int:post_id>/share/', share_post, name='share_post'),




]
