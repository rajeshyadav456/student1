from django.shortcuts import render
from .models import *
# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, get_object_or_404
from django.core.paginator import Paginator
from django.core.mail import send_mail
from django.http import HttpResponseRedirect
from .forms import *
from django.contrib.auth.decorators import login_required

def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirect to login page after successful signup
    else:
        form = UserCreationForm()
    return render(request, 'signup.html', {'form': form})





def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Replace 'home' with your desired URL
        else:
            # Handle invalid login
            pass
    return render(request, 'login.html')
def home(request):
    return render(request,'home.html')




def post_list(request):
    posts = Post.objects.all()
    paginator = Paginator(posts, 5)  # Display 5 posts per page
    page_number = request.GET.get('page')
    page_posts = paginator.get_page(page_number)
    return render(request, 'post_list.html', {'page_posts': page_posts})


def post_detail(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    comments = Comment.objects.filter(post=post).order_by('-created_at')
    comment_form = CommentForm()

    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            new_comment = comment_form.save(commit=False)
            new_comment.post = post
            new_comment.user = request.user  # Assign the user field
            new_comment.save()
            comment_form = CommentForm()

    context = {
        'post': post,
        'comments': comments,
        'comment_form': comment_form,
    }
    return render(request, 'post_detail.html', context)

def like_comment(request, comment_id):
    comment = get_object_or_404(Comment, pk=comment_id)
    user = request.user
    existing_like = Like.objects.filter(user=user, comment=comment).exists()
    if not existing_like:
        like = Like(user=user, comment=comment)
        like.save()
    return redirect('post_detail', post_id=comment.post.id)

def share_post(request, post_id):
    post = get_object_or_404(Post, pk=post_id)
    if request.method == 'POST':
        recipient_email = request.POST.get('recipient_email')
        subject = f"Check out this blog post: {post.title}"
        message = f"Read the blog post '{post.title}' at {request.build_absolute_uri(post.get_absolute_url())}"
        from_email = 'your_email@example.com'  # Your sender email
        send_mail(subject, message, from_email, [recipient_email])
        # Optionally, you can add a success message here
    return redirect('post_detail', post_id=post_id)