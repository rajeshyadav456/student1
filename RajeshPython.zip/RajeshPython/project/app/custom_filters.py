from django import template
from .models import Comment

register = template.Library()

@register.filter(name='count_likes')
def count_likes(comment):
    return comment.like_set.count()